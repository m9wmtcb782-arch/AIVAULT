alter table public.aivault_game_players enable row level security;
alter table public.aivault_game_cities enable row level security;
alter table public.aivault_game_buildings enable row level security;
alter table public.aivault_game_resources enable row level security;
alter table public.aivault_game_armies enable row level security;
alter table public.aivault_game_technology enable row level security;
alter table public.aivault_game_messages enable row level security;
alter table public.aivault_game_battles enable row level security;
alter table public.aivault_game_alliances enable row level security;
alter table public.aivault_game_alliance_members enable row level security;
alter table public.aivault_game_friends enable row level security;
alter table public.aivault_game_coupon_transactions enable row level security;

create policy players_read on public.aivault_game_players for select using (true);
create policy players_self on public.aivault_game_players for update using (user_id = auth.uid());

create policy cities_read on public.aivault_game_cities for select using (true);
create policy buildings_read on public.aivault_game_buildings for select using (true);
create policy resources_self on public.aivault_game_resources for select using (
  player_id in (select id from aivault_game_players where user_id = auth.uid())
);
create policy armies_self on public.aivault_game_armies for select using (
  player_id in (select id from aivault_game_players where user_id = auth.uid())
);
create policy tech_self on public.aivault_game_technology for select using (
  player_id in (select id from aivault_game_players where user_id = auth.uid())
);

create policy msg_read on public.aivault_game_messages for select using (
  channel_type = 'world'
  or (channel_type = 'private' and (
    sender_id in (select id from aivault_game_players where user_id = auth.uid())
    or receiver_id in (select id from aivault_game_players where user_id = auth.uid())
  ))
  or (channel_type = 'alliance' and alliance_id in (
    select alliance_id from aivault_game_players where user_id = auth.uid()
  ))
);

create policy battles_read on public.aivault_game_battles for select using (
  attacker_id in (select id from aivault_game_players where user_id = auth.uid())
  or defender_id in (select id from aivault_game_players where user_id = auth.uid())
);

create policy alliances_read on public.aivault_game_alliances for select using (true);
create policy coupon_self on public.aivault_game_coupon_transactions for select using (user_id = auth.uid());

-- Mutations go through SECURITY DEFINER RPCs only. No direct client UPDATE on resources/army/levels.
