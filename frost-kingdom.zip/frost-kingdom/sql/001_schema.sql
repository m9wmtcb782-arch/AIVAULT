-- AIVAULT FROST KINGDOM schema
-- Run in AIVAULT Supabase SQL editor. Do not expose service role to the client.

create table if not exists public.aivault_game_players (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique not null references auth.users(id) on delete cascade,
  name text unique not null check (char_length(name) between 2 and 20),
  level int not null default 1,
  exp int not null default 0,
  vip int not null default 0,
  power int not null default 0,
  avatar text,
  alliance_id uuid,
  compute_opt_in boolean not null default false,
  is_ai boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.aivault_game_cities (
  id uuid primary key default gen_random_uuid(),
  player_id uuid not null references public.aivault_game_players(id) on delete cascade,
  name text not null,
  level int not null default 1,
  x int not null,
  y int not null,
  hp int not null default 1000,
  shield_until timestamptz,
  is_ai boolean not null default false
);

create table if not exists public.aivault_game_buildings (
  id uuid primary key default gen_random_uuid(),
  city_id uuid not null references public.aivault_game_cities(id) on delete cascade,
  building_type text not null,
  level int not null default 1,
  upgrade_started_at timestamptz,
  upgrade_finish_at timestamptz
);

create table if not exists public.aivault_game_resources (
  player_id uuid primary key references public.aivault_game_players(id) on delete cascade,
  wood int not null default 0,
  food int not null default 0,
  stone int not null default 0,
  iron int not null default 0,
  gold int not null default 0,
  last_tick_at timestamptz not null default now()
);

create table if not exists public.aivault_game_armies (
  player_id uuid primary key references public.aivault_game_players(id) on delete cascade,
  warrior int not null default 0,
  archer int not null default 0,
  cavalry int not null default 0,
  mage int not null default 0,
  wounded_warrior int not null default 0,
  wounded_archer int not null default 0,
  wounded_cavalry int not null default 0,
  wounded_mage int not null default 0,
  training jsonb,
  healing jsonb
);

create table if not exists public.aivault_game_technology (
  id uuid primary key default gen_random_uuid(),
  player_id uuid not null references public.aivault_game_players(id) on delete cascade,
  tech_id text not null,
  level int not null default 0,
  research_finish_at timestamptz,
  unique (player_id, tech_id)
);

create table if not exists public.aivault_game_messages (
  id uuid primary key default gen_random_uuid(),
  channel_type text not null check (channel_type in ('world','alliance','private')),
  alliance_id uuid,
  sender_id uuid not null references public.aivault_game_players(id),
  receiver_id uuid references public.aivault_game_players(id),
  body text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.aivault_game_battles (
  id uuid primary key default gen_random_uuid(),
  attacker_id uuid not null references public.aivault_game_players(id),
  defender_id uuid not null references public.aivault_game_players(id),
  result text not null,
  report jsonb not null,
  created_at timestamptz not null default now()
);

create table if not exists public.aivault_game_alliances (
  id uuid primary key default gen_random_uuid(),
  name text unique not null,
  leader_id uuid not null,
  level int not null default 1,
  created_at timestamptz not null default now()
);

create table if not exists public.aivault_game_alliance_members (
  player_id uuid primary key references public.aivault_game_players(id) on delete cascade,
  alliance_id uuid not null references public.aivault_game_alliances(id) on delete cascade,
  role text not null check (role in ('Leader','Officer','Member'))
);

create table if not exists public.aivault_game_friends (
  a uuid not null references public.aivault_game_players(id) on delete cascade,
  b uuid not null references public.aivault_game_players(id) on delete cascade,
  status text not null check (status in ('pending','accepted')),
  primary key (a,b)
);

create table if not exists public.aivault_game_coupon_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  player_id uuid not null,
  amount int not null,
  transaction_type text not null check (transaction_type in ('spend','reward','refund')),
  reference_type text,
  reference_id text,
  balance_before int,
  balance_after int,
  created_at timestamptz not null default now()
);

create table if not exists public.aivault_game_tasks (
  id uuid primary key default gen_random_uuid(),
  player_id uuid not null,
  task_key text not null,
  progress int not null default 0,
  completed boolean not null default false
);

create table if not exists public.aivault_game_world_events (
  id uuid primary key default gen_random_uuid(),
  event_type text not null,
  payload jsonb,
  starts_at timestamptz not null,
  ends_at timestamptz not null
);

create table if not exists public.aivault_game_compute_nodes (
  player_id uuid primary key,
  opted_in boolean not null default false,
  last_heartbeat timestamptz
);

create table if not exists public.aivault_game_compute_tasks (
  id uuid primary key default gen_random_uuid(),
  task_type text not null,
  model_id text,
  model_version text,
  input jsonb,
  expected_output_schema jsonb,
  max_runtime int,
  priority int default 0,
  lease_until timestamptz,
  status text default 'queued'
);

alter table public.aivault_game_players
  add constraint aivault_game_players_alliance_fk
  foreign key (alliance_id) references public.aivault_game_alliances(id);
