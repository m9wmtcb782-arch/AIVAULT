-- Core RPCs. Mirror js/engine.js + js/store.js. SECURITY DEFINER + auth.uid() checks.

create or replace function public.aivault_game_bootstrap_v1(p_name text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  pid uuid;
  cid uuid;
  xy record;
begin
  if uid is null then raise exception 'NOT_AUTH'; end if;
  if exists(select 1 from aivault_game_players where user_id = uid) then
    raise exception 'PLAYER_EXISTS';
  end if;
  if char_length(trim(p_name)) < 2 or char_length(trim(p_name)) > 20 then
    raise exception 'BAD_NAME';
  end if;
  insert into aivault_game_players(user_id, name, avatar)
  values (uid, trim(p_name), left(trim(p_name),1))
  returning id into pid;

  select floor(random()*22+1)::int as x, floor(random()*22+1)::int as y into xy;
  insert into aivault_game_cities(player_id, name, x, y, shield_until)
  values (pid, trim(p_name) || ' 王城', xy.x, xy.y, now() + interval '1 hour')
  returning id into cid;

  insert into aivault_game_buildings(city_id, building_type, level)
  values (cid,'castle',2),(cid,'lumber',1),(cid,'farm',1),(cid,'stone',1),
         (cid,'iron',1),(cid,'barracks',1),(cid,'hospital',1),(cid,'tech',1);

  insert into aivault_game_resources(player_id, wood, food, stone, iron, gold)
  values (pid, 500, 500, 300, 200, 50);

  insert into aivault_game_armies(player_id, warrior, archer)
  values (pid, 12, 8);

  insert into aivault_game_technology(player_id, tech_id, level)
  values (pid,'economy',0),(pid,'military',0),(pid,'defense',0),
         (pid,'ai',0),(pid,'construction',0),(pid,'research',0);

  return jsonb_build_object('id', pid, 'name', trim(p_name));
end;
$$;

create or replace function public.aivault_game_snapshot_v1()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  p aivault_game_players%rowtype;
  c aivault_game_cities%rowtype;
begin
  if uid is null then raise exception 'NOT_AUTH'; end if;
  select * into p from aivault_game_players where user_id = uid;
  if p.id is null then raise exception 'NO_PLAYER'; end if;
  select * into c from aivault_game_cities where player_id = p.id limit 1;
  return jsonb_build_object(
    'player', to_jsonb(p),
    'city', to_jsonb(c),
    'buildings', (select coalesce(jsonb_agg(b), '[]'::jsonb) from aivault_game_buildings b where b.city_id = c.id),
    'resources', (select to_jsonb(r) from aivault_game_resources r where r.player_id = p.id),
    'army', (select to_jsonb(a) from aivault_game_armies a where a.player_id = p.id),
    'techs', (select coalesce(jsonb_agg(t), '[]'::jsonb) from aivault_game_technology t where t.player_id = p.id),
    'coupons', 0
  );
end;
$$;

-- Coupons: join your existing AIVAULT coupon table inside this function.
-- Replace the constant 0 with a select from the official ledger.

grant execute on function public.aivault_game_bootstrap_v1(text) to authenticated;
grant execute on function public.aivault_game_snapshot_v1() to authenticated;
