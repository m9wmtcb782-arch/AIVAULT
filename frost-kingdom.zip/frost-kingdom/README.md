# AIVAULT FROST KINGDOM

手機瀏覽器可玩的 2D 冰雪策略 MMO 前端 + 權威規則引擎。  
入口是 `game-start.html`（沒有 `index.html`）。

## 現在就能玩（本機權威引擎）

沒有 AIVAULT Supabase 金鑰時，`js/env.js` 的 `useLocalEngine: true` 會啟用與 RPC 相同規則的本機引擎：

- 註冊 / 登入 / 記住 Email / 忘記密碼（本機驗證）
- 建立角色與城市、AI 王國、資源生產
- 建築升級、科技、訓練、醫院、戰鬥結算
- 世界 / 聯盟 / 私聊、聯盟、商店扣券、競技場挑戰

同一支手機的兩個帳號可互相打（登出再註冊第二個）。  
跨裝置真實多人：填入 Supabase 後關掉本機引擎。

啟動（專案目錄）：

```bash
python3 -m http.server 8787
```

手機與電腦瀏覽器打開：

`http://本機IP:8787/game-start.html`

## 接到 AIVAULT Supabase

1. 在專案 SQL editor 依序執行 `sql/001_schema.sql`、`sql/002_rpc.sql`、`sql/003_rls.sql`
2. 編輯 `js/env.js`：

```js
supabaseUrl: "https://YOUR.supabase.co",
supabaseAnonKey: "YOUR_ANON_KEY",
useLocalEngine: false
```

3. 把官方 Coupons 餘額查詢寫進 `aivault_game_snapshot_v1`（現在回傳 0，避免前端自己改券）
4. 其餘動作補齊與 `js/api.js` 同名的 RPC

## 頁面

`game-start` → `game-login` / `game-register` / `game-forgot-password` → `game-create-player` → `game-world`  
底欄：主城、世界、軍隊、聊天、更多。

## 原則

資源、軍隊、等級、戰鬥、Coupons 只經 API。  
智慧核心預設關閉，與 Coupons 分離，不是挖礦。
