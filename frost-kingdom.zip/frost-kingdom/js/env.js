/**
 * AIVAULT Frost Kingdom — environment
 * Fill supabaseUrl + supabaseAnonKey to switch from local engine to live AIVAULT.
 * Never commit real service-role keys. Anon key only.
 */
window.AIVAULT_CONFIG = {
  supabaseUrl: "",
  supabaseAnonKey: "",
  /* true = playable without Supabase (same rules as RPC). Set false when URL+key exist. */
  useLocalEngine: true,
  worldSize: 24,
  tickSeconds: 30
};
