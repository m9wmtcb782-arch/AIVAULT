(function (w) {
  let ctx, nodes = [], on = localStorage.getItem("aivault_game_music") !== "off";
  function start() {
    if (!on) return;
    if (ctx) return;
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    const master = ctx.createGain();
    master.gain.value = 0.035;
    master.connect(ctx.destination);
    const notes = [110, 146.8, 164.8, 196];
    notes.forEach((f, i) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = i % 2 ? "sine" : "triangle";
      o.frequency.value = f;
      g.gain.value = 0.15 + i * 0.04;
      o.connect(g); g.connect(master);
      o.start();
      nodes.push(o);
    });
    const lfo = ctx.createOscillator();
    const lg = ctx.createGain();
    lfo.frequency.value = 0.07;
    lg.gain.value = 0.012;
    lfo.connect(lg); lg.connect(master.gain);
    lfo.start();
  }
  function stop() {
    if (ctx) { ctx.close(); ctx = null; nodes = []; }
  }
  function toggle() {
    on = !on;
    localStorage.setItem("aivault_game_music", on ? "on" : "off");
    if (on) start(); else stop();
    renderFab();
  }
  function renderFab() {
    let el = document.getElementById("musicFab");
    if (!el) {
      el = document.createElement("button");
      el.id = "musicFab";
      el.className = "music-fab";
      el.onclick = toggle;
      document.body.appendChild(el);
    }
    el.textContent = on ? "🎵 Music ON" : "🎵 Music OFF";
  }
  function boot() {
    renderFab();
    const unlock = () => { if (on) start(); document.removeEventListener("pointerdown", unlock); };
    document.addEventListener("pointerdown", unlock);
  }
  w.FKAudio = { start, stop, toggle, boot, isOn: () => on };
})(window);
