(function (w) {
  function cfg() { return w.AIVAULT_CONFIG || {}; }
  function useLocal() {
    return cfg().useLocalEngine || !cfg().supabaseUrl || !cfg().supabaseAnonKey;
  }
  function sb() { return w.FKAuth && w.FKAuth.client(); }

  async function rpc(name, args) {
    if (useLocal()) throw new Error("LOCAL");
    const { data, error } = await sb().rpc(name, args);
    if (error) throw new Error(error.message);
    return data;
  }

  const API = {
    mode() { return useLocal() ? "local" : "supabase"; },
    async signUp(email, password) {
      if (useLocal()) return FKLocal.register(email, password);
      const { data, error } = await sb().auth.signUp({ email, password });
      if (error) throw new Error(error.message);
      return data;
    },
    async signIn(email, password) {
      if (useLocal()) return FKLocal.login(email, password);
      const { data, error } = await sb().auth.signInWithPassword({ email, password });
      if (error) throw new Error(error.message);
      return data;
    },
    async signOut() {
      if (useLocal()) return FKLocal.logout();
      await sb().auth.signOut();
    },
    async session() {
      if (useLocal()) {
        const s = FKLocal.session();
        return s ? { user: { id: s.user_id, email: s.email } } : null;
      }
      const { data } = await sb().auth.getSession();
      return data.session;
    },
    async resetPassword(email) {
      if (useLocal()) return FKLocal.resetMail(email);
      const { error } = await sb().auth.resetPasswordForEmail(email);
      if (error) throw new Error(error.message);
    },
    async userId() {
      const s = await API.session();
      return s?.user?.id || null;
    },
    async getPlayer() {
      const uid = await API.userId();
      if (!uid) return null;
      if (useLocal()) return FKLocal.getPlayerByUser(uid);
      const { data, error } = await sb().from("aivault_game_players").select("*").eq("user_id", uid).maybeSingle();
      if (error) throw new Error(error.message);
      return data;
    },
    async bootstrap(name) {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.bootstrap(uid, name);
      return rpc("aivault_game_bootstrap_v1", { p_name: name });
    },
    async snapshot() {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.snapshot(uid);
      return rpc("aivault_game_snapshot_v1", {});
    },
    async world() {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.world(uid);
      return rpc("aivault_game_world_v1", {});
    },
    async playerPublic(id) {
      if (useLocal()) return FKLocal.playerPublic(id);
      return rpc("aivault_game_player_public_v1", { p_player_id: id });
    },
    async upgrade(buildingId) {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.upgradeBuilding(uid, buildingId);
      return rpc("aivault_game_upgrade_building_v1", { p_building_id: buildingId });
    },
    async research(techId) {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.research(uid, techId);
      return rpc("aivault_game_research_v1", { p_tech_id: techId });
    },
    async train(type, qty) {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.train(uid, type, qty);
      return rpc("aivault_game_train_v1", { p_type: type, p_qty: qty });
    },
    async heal() {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.heal(uid);
      return rpc("aivault_game_heal_v1", {});
    },
    async speedup(kind) {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.speedup(uid, kind, 5);
      return rpc("aivault_game_speedup_v1", { p_kind: kind });
    },
    async attack(targetId, march) {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.attack(uid, targetId, march);
      return rpc("aivault_game_attack_v1", { p_target: targetId, p_march: march });
    },
    async messages(channel, extra) {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.messages(uid, channel, extra);
      return rpc("aivault_game_messages_v1", { p_channel: channel, p_extra: extra || null });
    },
    async sendMessage(channel, body, extra) {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.sendMessage(uid, channel, body, extra);
      return rpc("aivault_game_send_message_v1", { p_channel: channel, p_body: body, p_extra: extra || null });
    },
    async createAlliance(name) {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.createAlliance(uid, name);
      return rpc("aivault_game_alliance_create_v1", { p_name: name });
    },
    async listAlliances() {
      if (useLocal()) return FKLocal.listAlliances();
      return rpc("aivault_game_alliance_list_v1", {});
    },
    async joinAlliance(id) {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.joinAlliance(uid, id);
      return rpc("aivault_game_alliance_join_v1", { p_id: id });
    },
    async leaveAlliance() {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.leaveAlliance(uid);
      return rpc("aivault_game_alliance_leave_v1", {});
    },
    async setCompute(on) {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.setCompute(uid, on);
      return rpc("aivault_game_set_compute_v1", { p_on: on });
    },
    async couponHistory() {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.couponHistory(uid);
      return rpc("aivault_game_coupon_history_v1", {});
    },
    async battles() {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.battlesFor(uid);
      return rpc("aivault_game_battles_v1", {});
    },
    async searchPlayers(q) {
      if (useLocal()) return FKLocal.searchPlayers(q);
      return rpc("aivault_game_search_players_v1", { p_q: q });
    },
    async friendAction(id, act) {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.friendAction(uid, id, act);
      return rpc("aivault_game_friend_v1", { p_target: id, p_act: act });
    },
    async shopBuy(sku) {
      const uid = await API.userId();
      if (useLocal()) return FKLocal.shopBuy(uid, sku);
      return rpc("aivault_game_shop_buy_v1", { p_sku: sku });
    }
  };
  w.FKApi = API;
})(window);
